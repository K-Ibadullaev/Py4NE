# main script
from Person import Person
#from PersonGUI import App
from PGUI import App


if __name__ == "__main__":
   # call app
    app = App()
    app.mainloop()